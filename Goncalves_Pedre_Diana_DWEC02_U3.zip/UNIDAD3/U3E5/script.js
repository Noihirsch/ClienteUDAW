// EJERCICIO 5 (objeto Number)
// Crea un programa que pida al usuario un número entero por pantalla y muestre:
// Su valor exponencial.
// El número con 4 decimales.
// El número en binario.
// El número en octal.
// El número en hexadecimal.
// Utiliza para ello los métodos del objeto Number.
// Por ejemplo si metes 50, deberías obtener: 5e1 / 50.0000 / 00110010 / 62 / 0x32


function operateWithInt(){
    let val1;
    pow(val1,val1);
    var mes = document.getElementById("mes").value;





}
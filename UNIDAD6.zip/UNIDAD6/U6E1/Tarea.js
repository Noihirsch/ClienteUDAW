    export default class Tarea {
        constructor(texto) {
            this.texto = texto;
            this.realizada = false;
        }
    }


    

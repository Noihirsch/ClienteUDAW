var saludarCadaTanto = setInterval(comenzarSaludos, 3000);

function comenzarSaludos(){
let saludar = alert("Hola!");
}

function pararSaludos(){
    clearTimeout(saludar);
}

//Crea un programa en el que crees 4 variables, 2 cadenas y 2 números,  con los siguientes valores: tu nombre, tu apellido, tu edad y tu año de nacimiento.
//Muestra en un alert una frase que incluya comillas simples.
//Muestra en un alert tu nombre y apellidos separados por un salto de línea.
//Muestra en un alert la suma de las variables edad y año de nacimiento.
//Muestra en un alert la suma de todas las variables.
//Comenta el código con los comentarios que estimes necesarios.


let firstName = 'Diana';  
let surname = 'Goncalves';
let age = 21;
let birthYear = 2002;

alert('Al que madruga, Dios le ayuda');
alert(firstName + '\n' + surname);
alert('Resultado suma: ' + (age + birthYear));
alert(firstName+surname+age+birthYear);
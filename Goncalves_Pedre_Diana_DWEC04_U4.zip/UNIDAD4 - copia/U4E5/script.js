import {Player} from "./player";
let player1 = new Player("Pepe");